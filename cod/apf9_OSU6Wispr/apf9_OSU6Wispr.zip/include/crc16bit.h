#ifndef CRC16BIT_H
#define CRC16BIT_H

/* function prototype */
unsigned int Crc16Bit(const unsigned char *msg,unsigned int len);

#endif /* CRC16BIT_H */
