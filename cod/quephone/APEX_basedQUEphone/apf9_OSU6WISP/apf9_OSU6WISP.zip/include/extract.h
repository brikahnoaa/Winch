#ifndef EXTRACT_H
#define EXTRACT_H

char *extract(const char *source,int index,int n);

#endif /* EXTRACT_H */
