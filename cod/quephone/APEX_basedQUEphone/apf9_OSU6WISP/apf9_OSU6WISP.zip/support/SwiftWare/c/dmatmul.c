/****************************************/
/*       member of math library         */
/****************************************/
#include <defs.p>

#define PRECISION double
#define MATMUL dmatmul_

#include <matmul.c>
