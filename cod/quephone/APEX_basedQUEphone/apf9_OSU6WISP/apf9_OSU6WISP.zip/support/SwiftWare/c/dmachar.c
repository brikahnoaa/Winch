#define PRECISION double
#define MACHAR dmachar
#include "machar.c"
 
