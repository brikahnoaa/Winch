#define DOUBLE (1)
#define PROFILE_CPP
#include "profile.cpp"
